START_MSG = """
This bot can mirror from links|tgfiles|torrents|nzb|rclone-cloud to any rclone cloud, Google Drive or to telegram.
Type /{cmd} to get a list of available commands
"""
START_BUTTON1 = "Git Repo"
START_BUTTON2 = "Updates"
